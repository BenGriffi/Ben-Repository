2nd part of the game dev course has example code that is pre-typed for the students
