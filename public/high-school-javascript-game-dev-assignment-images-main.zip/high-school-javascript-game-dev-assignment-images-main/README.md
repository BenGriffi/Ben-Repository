# high-school-javascript-game-dev-assignment-images
All the assignments for Game Dev as images


## Possible online editors

https://www.w3schools.com/js/tryit.asp?filename=tryjs_editor


https://codepen.io/pen/   click the "Strat Coding" button and put all the code into the html side


http://jsbin.com/?html,output


https://liveweave.com/




## index.html

![image](https://user-images.githubusercontent.com/5605614/136431433-54a33ab7-3c84-4da3-83f9-1abb1157d325.png)

## t1a01-basic-web-page-fred.html
![image](https://user-images.githubusercontent.com/5605614/136432901-59fd10a0-1989-451d-a035-a77b89378685.png)


##  t1a02-lists-tables-fred.html  

![image](https://user-images.githubusercontent.com/5605614/136432506-0674effe-f041-4abe-a2ed-d5ce83190a6d.png)

##   t1a03-forms-fred.html

![image](https://user-images.githubusercontent.com/5605614/136432571-5fc0175d-a118-4880-af28-23a8b2a7a704.png)



##   t1a04-css-by-fred.html 

![image](https://user-images.githubusercontent.com/5605614/136432646-96ee97a1-ec9a-4421-bfb5-a19186fa122e.png)


https://cssreference.io/

http://www.cheat-sheets.org/sites/css.su/

https://www.w3schools.com/html/html_css.asp



##    t1a05-input-output-by-fred.html

![image](https://user-images.githubusercontent.com/5605614/136432695-cba7d8e8-1889-4274-8585-0440b3c19d68.png)

##    t1a06-variables-by-fred.html

![image](https://user-images.githubusercontent.com/5605614/136613574-6f506b7e-4e39-4ff2-a3d0-9b04ca0d6211.png)


##  t1a07-decision-by-Fred.html

![image](https://user-images.githubusercontent.com/5605614/139138583-aae3b176-1c1e-4cdd-a5f9-08b4dc253051.png)




## t1a08-loops-by-fred.html


![image](https://user-images.githubusercontent.com/5605614/138125931-101dd806-6c71-4165-aa57-c9a66bd271ad.png)


##  t1a09-functions-by-fred.html

![image](https://user-images.githubusercontent.com/5605614/137364601-42f1fd28-6bed-4075-8c42-7ef16fd20883.png)



##   t1a10-events-by-fred.html 

![image](https://user-images.githubusercontent.com/5605614/138961028-2cdc2277-38ee-4f9a-8aab-79d6f49db917.png)


## t2a01-arrays-by-fred.html

![image](https://user-images.githubusercontent.com/5605614/139917299-f95b9794-ee45-4dba-92be-7b5e31fbe1ae.png)


##   t2a02-objects-by-fred.html

![image](https://user-images.githubusercontent.com/5605614/140102183-f82d3488-276a-4c55-b650-6eb8eb5b26d4.png)


##   t2a03-classes-by-fred.html

![image](https://user-images.githubusercontent.com/5605614/140825043-04ffad57-5e28-4a54-a72d-833ffd2554cf.png)


##   t2a04-extend-class-by-fred.html

![image](https://user-images.githubusercontent.com/5605614/141003275-7b76636e-1996-4033-9bc8-2ac320c51021.png)





##  Code for  T2A05-review-by-fred

On one webpage get all the code working from the following page

as a webpage https://hpssjellis.github.io/beginner-tensorflowjs-examples-in-javascript/beginner-examples/tfjs06-javascript.html




##  Code for  [t2a06-spy-by-fred.html](public/t2a06-spy-by-fred.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a06-spy-by-fred.html



##  Code for  [t2a07-move-background-name.html](public/t2a07-move-background-name.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a07-move-background-name.html


##  Code for  [t2a08-canvas-name.html](public/t2a08-canvas-name.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a08-canvas-name



##  Code for  [t2a09-local-storage-name.html](public/t2a09-local-storage-name.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a09-local-storage-name.html

------------------

##  Code for  [t2a10-translate-name.html](public/t2a10-translate-name.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a10-translate-name.html



##  Code for  [t2a10b-sound-by-fred.html](public/t2a10b-sound-by-fred.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a10b-sound-by-fred.html

-----------------

##  Code for  [t2a11-game-template-fred.html](public/t2a11-game-template-fred.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a11-game-template-fred.html


The key to understanding collisions in the game template is this bit of code

![image](https://user-images.githubusercontent.com/5605614/142253313-4d8eb9f5-8671-4ff1-bdd0-4b09973b7aa7.png)



##  Code for  [t2a12-sort-name2.html](public/t2a12-sort-name2.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/t2a12-sort-name2.html





## Helpers Not for marks




##  Helper Not for marks  [x-keydown.html](public/x-keydown.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/x-keydown.html




##   Helper Not for marks   [x-rotate01.html](public/x-rotate01.html)

as a webpage https://hpssjellis.github.io/high-school-javascript-game-dev-assignment-images/public/x-rotate01.html



## Helper not for marks.   [x-browser-hack.html](x-browser-hack.html)
Hack your browser to find all the objects, method (functions) and Properites (variables) preset on your browser.





##  Proof-level1-draft-uploaded. 

Use the game template  [t2a11-game-template-fred.html](public/t2a11-game-template-fred.html)  to make your level1 game. The level1 game must be finished to pass the course

## Proof-level2-draft-uploaded- 

This can be a continuation of the level1 2D Javascript game above or your own game engine or the following:

Typically we use [Construct3](https://www.construct.net/en) online, you do not have to register

1. click "Try now"
2. click on a template, some are paid ones I suggest to try "Driving"
3. Click preview, play game to make sure it works
4. Menu --> Project --> Export --> Web (HTML5) --> Next --> Next --> click Download...template.zip
5. Extract the zipped file and drag the entire folder to your github
6. Create an index link to the folderr name
7. Test your online javascript level 2 game.









##




##







